# Config Package for CMake Integration

Please take a look at the [documentation](../docs/cmake.md) for further details.
