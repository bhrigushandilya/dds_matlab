/*
 *
 *
 * Distributed under the OpenDDS License.
 * See: http://www.opendds.org/license.html
 */

#include "DCPS/DdsDcps_pch.h" //Only the _pch include should start with DCPS/
#include "Time_Helper.h"

#if !defined (__ACE_INLINE__)
#include "Time_Helper.inl"
#endif /* __ACE_INLINE__ */
