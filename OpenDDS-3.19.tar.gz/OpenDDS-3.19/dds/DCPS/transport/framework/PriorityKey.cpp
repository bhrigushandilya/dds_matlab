/*
 *
 *
 * Distributed under the OpenDDS License.
 * See: http://www.opendds.org/license.html
 */

#include "DCPS/DdsDcps_pch.h"
#include "PriorityKey.h"

#if !defined (__ACE_INLINE__)
#include "PriorityKey.inl"
#endif /* __ACE_INLINE__ */
