/*
 *
 *
 * Distributed under the OpenDDS License.
 * See: http://www.opendds.org/license.html
 */

#include "DCPS/DdsDcps_pch.h" //Only the _pch include should start with DCPS/
#include "TransportStrategy.h"

OpenDDS::DCPS::TransportStrategy::~TransportStrategy()
{
}
